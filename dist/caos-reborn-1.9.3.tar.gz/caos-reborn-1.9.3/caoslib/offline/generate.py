def run_generator():
    pass
